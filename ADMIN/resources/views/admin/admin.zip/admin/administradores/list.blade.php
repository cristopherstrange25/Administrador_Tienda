@extends('admin.plantilla.layout')

@section('titulo')
    
@endsection
@section('contenido')
<p></p>
<p></p>
<div class="col-12">
      <button class="btn btn-primary" type="submit">Registrar</button>
</div>
<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Nombre</th>
      <th scope="col">Puesto</th>
      <th scope="col">Fecha de nacimiento</th>
      <th scope="col">Direccion</th>
      <th scope="col">Correo</th>
      <th scope="col">Telefono</th>
      <th scope="col">Imagen</th>
      <th scope="col">Editar</th>
      <th scope="col">Borrar</th>
    </tr>
  </thead>
  <tbody>
    @foreach ($administradores as $administrador)
    <tr>
    <th scope="row"> {{ $administrador->id }} </th>
    <td>{{ $administrador -> name }}</td>
    <td>{{ $administrador -> workstation }}</td>
    <td>{{ $administrador -> birthdate}}</td>
    <td>{{ $administrador -> address}}</td>
    <td>{{ $administrador -> email}}</td>
    <td>{{ $administrador -> phone}}</td>
    <td><img src ="{{ $administrador->picture }}" alt = "{{ $administrador -> picture }}" width="150" ></td>
    <td><a href="/administradores/editar/{{ $administrador->id }}" > editar </a></td>
    <td><a href="/administradores/mostrar/{{ $administrador->id }}" > borrar </a></td>
    </tr>
    @endforeach
  </tbody>
</table>
<div class="col-12">
    <a class="btn btn-primary" href="/administradores/crear">Agregar administrador</a>
</div>
@endsection

