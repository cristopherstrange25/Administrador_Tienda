@extends('admin.plantilla.layout')

@section('titulo')
    
@endsection
@section('contenido')

<p></p>
<p></p>
<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Nombre</th>
      <th scope="col">Contacto</th>
      <th scope="col">Imagen</th>
      <th scope="col">Direccion</th>
      <th scope="col">Telefono</th>
      <th scope="col">Correo</th>>
      <th scope="col">Situacion</th>
      <th scope="col">Editar</th>
      <th scope="col">Borrar</th>
    </tr>
  </thead>
  <tbody>
  @foreach ($proveedores as $proveedor) 
        
      <tr>
        <th scope="row"> {{ $proveedor->id }} </th>
        <td>{{ $proveedor->name }}</td>
        <td>{{ $proveedor->contact_name}}</td>
        <td><img src ="{{ $proveedor->picture }}" alt = "{{ $proveedor -> picture }}" width="150" ></td>
        <td>{{ $proveedor->address }}</td>
        <td>{{ $proveedor->phone }}</td>
        <td>{{ $proveedor->email }}</td>
        <td>{{ $proveedor->status }}</td>
        <td><a href="/proveedores/editar/{{ $proveedor->id }}" > editar </a></td>
      <td><a href="/proveedores/mostrar/{{ $proveedor->id }}" > borrar </a></td>
      </tr>
  @endforeach
  </tbody>
</table>
<div class="col-12">
    <a class="btn btn-primary" href="/proveedores/crear">Añadir proveedor</a>
</div>   
@endsection
